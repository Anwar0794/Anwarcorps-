**Project Name**: Anwarcorps  
**Token Symbol**: ACS  
**Contract Address**: 0xa6738d344b399ebf9a8d1806152279d3e2ae0d20  
**Decimals**: 18  
**Network**: Polygon  
**Total Supply**: 1,000,000,000  
**Website**: https://anwarcorps.blogspot.com  
**Whitepaper**: Included  
**Utility**: Payment, Staking  
**Explorer**: https://polygonscan.com/address/0xa6738d344b399ebf9a8d1806152279d3e2ae0d20  
**Social Media**:  
- Facebook: https://www.facebook.com/profile.php?id=61578715375897  
- YouTube: https://youtube.com/@anwargaming-t4o
